<?php

namespace App\Controllers;

use App\Models\KeuanganModel;

class Keuangan extends BaseController
{
    protected $keuangan;

    function __construct()
    {
        $this->keuangan = new KeuanganModel();
    }

    public function index()
    {
        $data['keuangan'] = $this->keuangan->findAll();
        return view('keuangan/index', $data);
    }

    public function create()
    {
        return view('keuangan/create');
    }

    public function store()
    {
        if (!$this->validate([
            'nama' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
            'ket' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
            'nominal' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
            'type' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],


        ])) {
            session()->setFlashdata('error', $this->validator->listErrors());
            return redirect()->back()->withInput();
        }

        $this->keuangan->insert([
            'nama' => $this->request->getVar('nama'),
            'ket' => $this->request->getVar('ket'),
            'nominal' => $this->request->getVar('nominal'),
            'type' => $this->request->getVar('type')
        ]);
        session()->setFlashdata('message', 'Tambah Keuangan Berhasil');
        return redirect()->to('/keuangan');
    }

    function edit($id)
    {
        $dataKeuangan = $this->keuangan->find($id);
        if (empty($dataKeuangan)) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Data Keuangan Tidak ditemukan !');
        }
        $data['keuangan'] = $dataKeuangan;
        return view('keuangan/edit', $data);
    }

    public function update($id)
    {
        if (!$this->validate([
            'nama' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
            'ket' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
            'nominal' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
            'type' => [
                'rules' => 'required',
                'errors' => [
                    'required' => '{field} Harus diisi'
                ]
            ],


        ])) {
            session()->setFlashdata('error', $this->validator->listErrors());
            return redirect()->back()->withInput();
        }

        $this->keuangan->update($id, [
            'nama' => $this->request->getVar('nama'),
            'ket' => $this->request->getVar('ket'),
            'nominal' => $this->request->getVar('nominal'),
            'type' => $this->request->getVar('type')
        ]);
        session()->setFlashdata('message', 'Update Keuangan Berhasil');
        return redirect()->to('/keuangan');
    }

    function delete($id)
    {
        $dataKeuangan = $this->keuangan->find($id);
        if (empty($dataKeuangan)) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Data Keuangan Tidak ditemukan !');
        }
        $this->keuangan->delete($id);
        session()->setFlashdata('message', 'Delete Data Keuangan Berhasil');
        return redirect()->to('/keuangan');
    }
}
