<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

use CodeIgniter\I18n\Time;

class KeuanganSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'nama'          =>  'Budi',
                'ket' =>  'Pembayaran Iuran Agustus',
                'nominal'       =>  '100000',
                'type'    =>  'Kredit',
                'created_at' => Time::now(),
                'updated_at' => Time::now()
            ]
        ];
        $this->db->table('keuangan')->insertBatch($data);
    }
}
